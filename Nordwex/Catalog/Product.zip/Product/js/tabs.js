// Найти все заголовки табов по дата атрибуту
const tabHeaders = document.querySelectorAll('[data-tab]');
// console.log(tabHeaders)

// Нашли все контент боксы
const contentBoxes = document.querySelectorAll('[data-tab-content]');
// console.log(contentBoxes)

tabHeaders.forEach(function(){

	tabHeaders.addEventListener('click', function(){
		this.classList.remove('tab_active')
	})
});

tabHeaders.forEach(function (item) {

	item.addEventListener('click', function (){

		// tabHeaders.classList.remove('tab_active');
		// tabHeaders.querySelectorAll(function () {
		// 	tabHeaders.classList.add('tab_active');
		// });

		// 1. Найти все контентбоксы и скрыть (Уже нашли)
		contentBoxes.forEach(function (item) {
			item.classList.add('hidden');
		});

		// 2. Выбрать нужный бокс и показать его

		const contentBox = document.querySelector('#' + this.dataset.tab);
		contentBox.classList.remove('hidden');
		tabHeaders.classList.add('hidden');
	})
})